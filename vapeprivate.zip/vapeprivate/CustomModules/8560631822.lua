local IS_LATEST = loadstring(game:HttpGet("https://raw.githubusercontent.com/fa899/vxpe-private-leak/main/version"))().v == "A1" and true or false
if IS_LATEST and IS_LATEST == false then
game.Players.LocalPlayer:Kick("Hello! Sadly, your vxpe configuration is out of date.\nTo update, you must go to:\nhttps://github.com/fa899/vxpe-private-leak/tree/main\n↑ YOU WILL HAVE TO REDOWNLOAD THIS EVERY UPDATE! ↑")
return warn('out of date')
end

shared.CustomSaveVape = 6872274481
if pcall(function() readfile("vapeprivate/CustomModules/6872274481.lua") end) then
	loadstring(readfile("vapeprivate/CustomModules/6872274481.lua"))()
end